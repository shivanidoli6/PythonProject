import requests
from bs4 import BeautifulSoup
import os

def finance():
    print(os.getcwd())
    #f = open("C:Users\Ramesh\PycharmProjects\untitled\venv\Scripts\tickers.txt", 'r')
    #file=f.read()
    for i in range(len(file)):
        print(i)

finance()
