import requests
from bs4 import BeautifulSoup
import os

url=requests.get('https://finance.yahoo.com/trending-tickers')
s=BeautifulSoup(url.text,'html.parser')

page=s.find(class_='yfinlist-table W(100%) BdB Bdc($tableBorderGray)')
ticker_logo=page.find_all(class_="data-col0 Ta(start) Pstart(6px) Pend(15px)")
ticker_logos=page.find_all('a')
ticker_name=page.find_all(class_="data-col1 Ta(start) Pstart(10px) Miw(180px)")
i=0
for logo in ticker_logos:
    if not 'react-empty:' in logo.contents[0]:
        symbol=logo.contents[0]
        if i<6:
            try:
                os.makedirs(os.path.join('Tickers',symbol))
                print("directory created")
            except:
                os.stat(os.path.join('Tickers',symbol))
                print("already exists")

            url1=requests.get('https://finance.yahoo.com/quote/'+symbol+'/profile?p='+symbol)
            s1=BeautifulSoup(url1.text,'html.parser')
            f1=open('Tickers/'+symbol+'/profile.html',"w")
            f1.write(str(s1.encode("utf-8")))


            url2=requests.get('https://finance.yahoo.com/quote/'+symbol+'/financials?p='+symbol)
            s2=BeautifulSoup(url2.text,'html.parser')
            f2=open('Tickers/'+symbol+'/finance.html',"w")
            f2.write(str(s2.encode("utf-8")))

            url3=requests.get('https://finance.yahoo.com/quote/'+symbol+'/key-statistics?p='+symbol)
            s3=BeautifulSoup(url3.text,'html.parser')
            f3=open('Tickers/'+symbol+'/statistics.html',"w")
            f3.write(str(s3.encode("utf-8")))

            url4=requests.get('https://finance.yahoo.com/quote/'+symbol+'?p='+symbol)
            s4=BeautifulSoup(url4.text,'html.parser')
            f4=open('Tickers/'+symbol+'/summary.html',"w")
            f4.write(str(s4.encode("utf-8")))
        i=i+1


        
 
  









