f = open(r'''tickers.txt''')
def finance():
    for i in f:
        j = i.replace('\n', '')
        # print(r'C:\Users\Ramesh\PycharmProjects\untitled\venv\Scripts\Tickers\\' +j+'\\finance.html')
        fi = open(r'C:\Users\Ramesh\PycharmProjects\untitled\venv\Scripts\Tickers\\' + j + '\\finance.html')
        so = BeautifulSoup(fi, "html.parser")

        fin_con = so.find_all(class_='Bdbw(1px) Bdbc($c-fuji-grey-c) Bdbs(s) H(36px)')
        # print(fin_con)
        count = 0
        finan = open("finance.txt", "w")
        for j in fin_con:
            d = j.find_all('td')
            for k in d:
                kd = k.text
                if (ord(kd[0]) > 64):
                    dk = k.text
                    if (dk == 'Net Income'):
                        count += 1
                if (dk == 'Revenue' or dk == 'Total Revenue' or dk == 'Cost of Revenue' or dk == 'Income Before Tax' or (dk == 'Net Income' and count == 2)):
                    #print(k.text)
                    finan.write(k.text)


finance()
