import requests
from bs4 import BeautifulSoup
import os

f=open("tickers.txt")

def profile():
    for i in f:
        j=i.replace('\n','')
        print(j)
        fi=open(r'C:\Users\Ramesh\PycharmProjects\untitled\venv\Scripts\Tickers\\'+j+'\\profile.html')
        so=BeautifulSoup(fi,"html.parser")

        prof_con=so.find_all(class_='asset-profile-container')
        prof_cont=prof_con.find('h3')
        prof_conte=prof_con.find('p')
        

   


profile()




















































